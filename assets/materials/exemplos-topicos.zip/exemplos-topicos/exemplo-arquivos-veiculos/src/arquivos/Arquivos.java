/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package arquivos;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;

/**
 *
 * @author 9584013
 */
public class Arquivos {

    public static void main(String[] args) {
        gravar();
        ler();
    }
    
    private static void ler() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("veiculos.txt")); 
            String resultado = "";
            String linha = reader.readLine();
            while(linha != null) {
                String[] conteudo = linha.split(";");
                
                String marca = conteudo[0];
                String modelo = conteudo[1];
                int ano = Integer.parseInt(conteudo[2]);
                
                resultado += "Marca: " + marca +
                        "\nModelo: " + modelo +
                        "\nAno: " + ano +"\n\n"; 
                
                linha = reader.readLine();
            }
            JOptionPane.showMessageDialog(null, resultado);
        } catch (FileNotFoundException ex) {
            System.out.println("Erro na leitura do arquivo!");
        } catch (IOException ex) {
            Logger.getLogger(Arquivos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    private static void gravar() {
        String marca = JOptionPane.showInputDialog("Informe a marca");
        String modelo = JOptionPane.showInputDialog("Informe o modelo");
        int ano = Integer.parseInt(JOptionPane.showInputDialog("Informe o ano"));
        
        try {
            FileWriter writer = new FileWriter("veiculos.txt", true); 
            writer.write(marca + ";" + modelo + ";" + ano);
            writer.write("\n");
            writer.close();
        } catch (IOException ex) {
            System.out.println("Erro na escrita do arquivo!");
        }
    }
    
}
