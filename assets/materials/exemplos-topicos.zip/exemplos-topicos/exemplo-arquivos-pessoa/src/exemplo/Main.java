/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplo;

import java.util.List;

/**
 *
 * @author 9584013
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Pessoa p1 = new Pessoa("José", 30, 'M');
        Pessoa p2 = new Pessoa("Maria", 12, 'F');
        Pessoa p3 = new Pessoa("Pedro", 45, 'M');
        Pessoa p4 = new Pessoa("Ana", 22, 'F');
        Pessoa p5 = new Pessoa("João", 60, 'M');
        
        PersistenciaArquivos.inserir(p1);
        PersistenciaArquivos.inserir(p2);
        PersistenciaArquivos.inserir(p3);
        PersistenciaArquivos.inserir(p4);
        PersistenciaArquivos.inserir(p5);
        
        Pessoa p6 = PersistenciaArquivos.ler("João");
        if(p6 != null) {
            System.out.println(p6.getNome() + " foi encontrado, ele possui " + p6.getIdade() + " anos de idade.");
        }
        
        System.out.println("");
        List<Pessoa> pessoas = PersistenciaArquivos.lerTodasPessoas();
        for(Pessoa p : pessoas) {
            System.out.println(p.toString());
        }
        
        PersistenciaArquivos.excluir("Ana");
        System.out.println("");
        pessoas = PersistenciaArquivos.lerTodasPessoas();
        for(Pessoa p : pessoas) {
            System.out.println(p.toString());
        }
    }
    
}
