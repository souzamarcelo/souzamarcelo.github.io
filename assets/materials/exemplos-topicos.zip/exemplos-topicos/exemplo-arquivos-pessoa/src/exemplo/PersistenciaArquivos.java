/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplo;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author 9584013
 */
public class PersistenciaArquivos {
    
    public static void excluir(String nome) {
        List<Pessoa> todasPessoas = lerTodasPessoas();
        String conteudo = "";
        for(Pessoa p : todasPessoas) {
            if(!p.getNome().equals(nome))
                conteudo += p.toWriteString() + "\n";
        }
        try {
            FileWriter writer = new FileWriter("pessoas.txt", false);
            writer.write(conteudo);
            writer.close();
        } catch (IOException ex) {
            Logger.getLogger(PersistenciaArquivos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public static List<Pessoa> lerTodasPessoas() {
        List<Pessoa> listaPessoas = new ArrayList<Pessoa>();
        try {
            BufferedReader reader = new BufferedReader(new FileReader("pessoas.txt"));
            String linha;
            while((linha = reader.readLine()) != null) {
                String[] conteudo = linha.split(";");
                Pessoa p = new Pessoa();
                p.setNome(conteudo[0]);
                p.setIdade(Integer.parseInt(conteudo[1]));
                p.setSexo(conteudo[2].charAt(0));
                listaPessoas.add(p);
            }
            reader.close();
        } catch (FileNotFoundException ex) {} catch (IOException ex) {}
        
        return listaPessoas;
    }
    
    public static Pessoa ler(String nome) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("pessoas.txt"));
            String linha;
            while((linha = reader.readLine()) != null) {
                String[] conteudo = linha.split(";");
                if(conteudo[0].equals(nome)) {
                    Pessoa p = new Pessoa();
                    p.setNome(conteudo[0]);
                    p.setIdade(Integer.parseInt(conteudo[1]));
                    p.setSexo(conteudo[2].charAt(0));
                    
                    reader.close();
                    return p;
                }
            }
            reader.close();
        } catch (FileNotFoundException ex) {} catch (IOException ex) {}
        
        return null;
    }
    
    public static void inserir(Pessoa p){
        try {
            FileWriter writer = new FileWriter("pessoas.txt", true);
            writer.write(p.toWriteString());
            writer.write("\n");
            writer.close();
        } catch (IOException ex) {
            Logger.getLogger(PersistenciaArquivos.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}