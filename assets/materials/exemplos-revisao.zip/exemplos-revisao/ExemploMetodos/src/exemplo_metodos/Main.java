/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplo_metodos;

import javax.swing.JOptionPane;

/**
 *
 * @author marcelo
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int primeiraIdade = Integer.parseInt(JOptionPane.showInputDialog("Informe a primeira idade"));
        int segundaIdade = Integer.parseInt(JOptionPane.showInputDialog("Informe a segunda idade"));
        
        JOptionPane.showMessageDialog(null, "A diferença das idades é " + diferencaIdades(primeiraIdade, segundaIdade));
    }
    
    public static int diferencaIdades(int i1, int i2) {
        if(comparaIdades(i1, i2))
            return i1 - i2;
        else
            return i2 - i1;
    }
    
    public static boolean comparaIdades(int i1, int i2) {
        return i1 > i2;
    }
    
}
