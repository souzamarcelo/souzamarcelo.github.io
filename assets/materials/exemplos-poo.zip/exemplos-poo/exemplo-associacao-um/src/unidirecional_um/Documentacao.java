/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unidirecional_um;

/**
 *
 * @author 9584013
 */
public class Documentacao {
    private int renavam;
    private int validade;
    private String placa;

    public Documentacao() {}

    public Documentacao(int renavam, int validade, String placa) {
        this.renavam = renavam;
        this.validade = validade;
        this.placa = placa;
    }

    public int getRenavam() {
        return renavam;
    }

    public void setRenavam(int renavam) {
        this.renavam = renavam;
    }

    public int getValidade() {
        return validade;
    }

    public void setValidade(int validade) {
        this.validade = validade;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }
}
