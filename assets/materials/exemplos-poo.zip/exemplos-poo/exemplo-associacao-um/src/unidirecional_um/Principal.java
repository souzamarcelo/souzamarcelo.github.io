/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unidirecional_um;

/**
 *
 * @author 9584013
 */
public class Principal {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Veiculo carro = new Veiculo("Focus", "Ford", 2017);
        Documentacao doc = new Documentacao(512647522, 2018, "QWD-2573");
        carro.setDoc(doc);
        System.out.println("O veículo " + carro.getModelo() + " possui placa " + carro.getDoc().getPlaca());
    }
    
}
