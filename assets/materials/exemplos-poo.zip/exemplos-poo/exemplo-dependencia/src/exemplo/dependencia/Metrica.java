/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplo.dependencia;

/**
 *
 * @author 9584013
 */
public class Metrica {
    private double emissao;
    private double ruido;
    private double consumo;

    public double getEmissao() {
        return emissao;
    }

    public void setEmissao(double emissao) {
        this.emissao = emissao;
    }

    public double getRuido() {
        return ruido;
    }

    public void setRuido(double ruido) {
        this.ruido = ruido;
    }

    public double getConsumo() {
        return consumo;
    }

    public void setConsumo(double consumo) {
        this.consumo = consumo;
    }
}
