/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplo.dependencia;

/**
 *
 * @author 9584013
 */
public class Veiculo {
    private String modelo;
    private String placa;
    private double combustivel;
    
    public void abastecer(Posto posto, double qtd) {
        if(posto.retiraCombustivel(qtd))
            this.combustivel += qtd;
    }
    
    public Metrica avaliar(double aceleracao) {
        Metrica m = new Metrica();
        if(aceleracao <= 10) {
            m.setConsumo(12);
            m.setRuido(41);
            m.setEmissao(340);
        } else {
            m.setConsumo(6);
            m.setRuido(70);
            m.setEmissao(510);
        }
        return m;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public double getCombustivel() {
        return combustivel;
    }

    public void setCombustivel(double combustivel) {
        this.combustivel = combustivel;
    }
}
