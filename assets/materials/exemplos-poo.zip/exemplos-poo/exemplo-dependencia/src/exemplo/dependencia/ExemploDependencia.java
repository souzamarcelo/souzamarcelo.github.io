/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplo.dependencia;

/**
 *
 * @author 9584013
 */
public class ExemploDependencia {
    public static void main(String[] args) {
        Posto p = new Posto();
        p.setNome("Posto XYZ");
        p.setValor(3.50);
        p.setEstoque(4500);
        
        Veiculo v = new Veiculo();
        v.setModelo("Gol");
        v.setPlaca("ABC-1234");
        v.setCombustivel(12.3);
        
        System.out.println("Combustível: " + v.getCombustivel());
        v.abastecer(p, 25);
        System.out.println("Combustível: " + v.getCombustivel());
        
        Metrica m = v.avaliar(22);
        System.out.println("Emissão: " + m.getEmissao() + 
                           "\nRuído: " + m.getRuido() + 
                           "\nConsumo: " + m.getConsumo());
    }
}
