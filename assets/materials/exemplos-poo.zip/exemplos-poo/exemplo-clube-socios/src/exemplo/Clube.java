/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 9584013
 */
public class Clube {
    private String nome;
    private String cidade;
    private List<Socio> socios;

    public Clube() {
        socios = new ArrayList<Socio>();
    }

    public Clube(String nome, String cidade) {
        this.nome = nome;
        this.cidade = cidade;
        this.socios = new ArrayList<Socio>();
    }
    
    public void addSocio(Socio socio) {
        this.socios.add(socio);
    }
    
    public boolean removeSocio(int matricula) {
        for(Socio s : socios) {
            if(s.getMatricula() == matricula) {
                this.socios.remove(s);
                return true;
            }
        }
        return false;
    }
    
    public List<Socio> getSocios() {
        return socios;
    }

    public void setSocios(List<Socio> socios) {
        this.socios = socios;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }
}
