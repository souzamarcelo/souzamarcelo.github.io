/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplo;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 9584013
 */
public class Exemplo {
    
    private List<Socio> socios = new ArrayList<Socio>();
    private List<Clube> clubes = new ArrayList<Clube>();
    
    public void run() {
        insereRegistros();
        removeSocio();
        mostraRegistros();
    }
    
    private void insereRegistros() {
        Socio s1 = new Socio(123456, "Maria da Rosa", 45);
        Socio s2 = new Socio(654321, "José da Silva", 25);
        Socio s3 = new Socio(147852, "Ana Lúcia da Silva", 30);
        Socio s4 = new Socio(369852, "Pedro Ferreira", 28);
        socios.add(s1);
        socios.add(s2);
        socios.add(s3);
        socios.add(s4);
        
        Clube c1 = new Clube("Clube ABC", "Ibirama");
        Clube c2 = new Clube("Clube XYZ", "Blumenau");
        clubes.add(c1);
        clubes.add(c2);
        
        c1.addSocio(s1);
        c1.addSocio(s2);
        c2.addSocio(s3);
        c2.addSocio(s4);
    }
    
    public void removeSocio() {
        Clube c = clubes.get(0);
        Socio s = socios.get(0);
        
        if(c.removeSocio(s.getMatricula())) {
            System.out.println("Sócio [" + s.getMatricula() + "] removido do clube " + c.getNome());
            socios.remove(s);
        } else {
            System.out.println("Sócio [" + s.getMatricula() + "] não pertence ao clube " + c.getNome());
        }
    }
    
    private void mostraRegistros() {
        for(Clube c : clubes) {
            System.out.println("Sócios do clube " + c.getNome());
            for(Socio s : c.getSocios()) {
                System.out.println("\t" + s.getNome() + " [" + s.getMatricula() + "]");
            }
            System.out.println("");
        }
    }
}
