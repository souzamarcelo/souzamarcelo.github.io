/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplo_um;

/**
 *
 * @author 9584013
 */
public class ExemploAgregacao {
    
    public static void main(String[] args) {
        SensorVelocidade sensor = new SensorVelocidade();
        sensor.setPrecisao(5);
        
        Radar radar1 = new Radar();
        radar1.setVelocidadeMaxima(50);
        radar1.setSensor(sensor);
        
        Radar radar2 = new Radar();
        radar2.setVelocidadeMaxima(80);
        radar2.setSensor(sensor);
    }
}
