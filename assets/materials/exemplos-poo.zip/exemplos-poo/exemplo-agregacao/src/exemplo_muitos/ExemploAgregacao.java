/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplo_muitos;

/**
 *
 * @author 9584013
 */
public class ExemploAgregacao {

    public static void main(String[] args) {
        Turma turma1 = new Turma();
        turma1.setAno(2017);
        turma1.setSemestre(2);
        
        Turma turma2 = new Turma();
        turma2.setAno(2018);
        turma2.setSemestre(1);
        
        Aluno aluno1 = new Aluno();
        aluno1.setMatricula("567432876");
        aluno1.setNome("João da Silva");
        
        Aluno aluno2 = new Aluno();
        aluno2.setMatricula("984367234");
        aluno2.setNome("Maria Pereira");
        
        turma1.getAlunos().add(aluno1);
        turma1.getAlunos().add(aluno2);
        turma2.getAlunos().add(aluno1);
    }
    
}
