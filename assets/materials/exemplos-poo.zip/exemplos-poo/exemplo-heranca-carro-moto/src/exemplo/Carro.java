/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplo;

/**
 *
 * @author 9584013
 */
public class Carro extends Veiculo {
    private int numPortas;

    @Override
    public double calculaImposto() {
        return super.calculaImposto() + 800;
    }
    
    public Carro() {
        super();
    }

    public Carro(int numPortas, String marca, String modelo, String cor, double valor) {
        super(marca, modelo, cor, valor);
        this.numPortas = numPortas;
    }

    public int getNumPortas() {
        return numPortas;
    }

    public void setNumPortas(int numPortas) {
        this.numPortas = numPortas;
    }
}
