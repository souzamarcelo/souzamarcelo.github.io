/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplo;

import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author 9584013
 */
public class Aplicacao {
    
    private List<Veiculo> veiculos = new ArrayList<Veiculo>();
    
    public void run() {
        criaRegistros();
        veiculosDaMarca("Fiat");
        mostraImpostos();
        mostraCarros();
    }
    
    private void mostraCarros() {
        String texto = "";
        for(Veiculo v: veiculos) {
            if(v instanceof Carro)
                texto += v.getMarca() + " " + v.getModelo() + ", cor " + v.getCor() + "\n";
        }
        JOptionPane.showMessageDialog(null, texto);
    }
    
    private void mostraImpostos() {
        String texto = "";
        for(Veiculo v : veiculos) {
            texto += v.getMarca() + " " + v.getModelo() + "(" + v.getValor() + "): " + v.calculaImposto() + "\n";
        }
        
        JOptionPane.showMessageDialog(null, texto);
    }
    
    private void veiculosDaMarca(String marca) {
        int qtd = 0;
        for(Veiculo v: veiculos) {
            if(v.getMarca().equals(marca))
                qtd++;
        }
        
        JOptionPane.showMessageDialog(null, "A marca " + marca + " possui " + qtd + " veículos!");
    }
    
    private void criaRegistros() {
        Carro c1 = new Carro(2, "VW", "Gol", "prata", 25000);
        Carro c2 = new Carro(4, "Fiat", "Uno", "branco", 20000);
        Carro c3 = new Carro(4, "Renault", "Clio", "preto", 32000);
        Carro c4 = new Carro(2, "Fiat", "147", "amarelo", 8000);
        
        Moto m1 = new Moto(150, "Honda", "CG", "azul", 7000);
        Moto m2 = new Moto(150, "Yamaha", "YBR", "vermelho", 12000);
        
        veiculos.add(c1);
        veiculos.add(c2);
        veiculos.add(c3);
        veiculos.add(c4);
        veiculos.add(m1);
        veiculos.add(m2);
    }
}
