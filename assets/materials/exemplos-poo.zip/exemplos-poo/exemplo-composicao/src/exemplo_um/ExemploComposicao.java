/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplo_um;

/**
 *
 * @author 9584013
 */
public class ExemploComposicao {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Computador c1 = new Computador();
        c1.addProcessador(4, 2.3);
        
        Computador c2 = new Computador();
        c2.addProcessador(4, 2.3);
        
        //c1 e c2 possuem processadores com os mesmos atributos,
        //mas são objetos diferentes!
    }
    
}
