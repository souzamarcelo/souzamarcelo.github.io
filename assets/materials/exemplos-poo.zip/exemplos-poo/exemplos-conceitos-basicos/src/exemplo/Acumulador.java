/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplo;

/**
 *
 * @author marcelo
 */
public class Acumulador {
    
    private long somaInteiros;
    
    public Acumulador() {
        this.somaInteiros = 0;
    }
    
    public Acumulador(long valorInicial) {
        this.somaInteiros = valorInicial;
    }
    
    public void soma(int valor) {
        this.somaInteiros += valor;
    }
    
    public void soma(String valor) {
        this.somaInteiros += Integer.parseInt(valor);
    }
}
