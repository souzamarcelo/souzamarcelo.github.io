/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unidirecional_um;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 9584013
 */
public class Empresa {
    private String razaoSocial;
    private String nomeFantasia;
    private String cnpj;
    private List<Funcionario> funcionarios;

    public void addFuncionario(Funcionario f) {
        this.funcionarios.add(f);
    }
    
    public Empresa() {
        funcionarios = new ArrayList<Funcionario>();
    }

    public Empresa(String razaoSocial, String nomeFantasia, String cnpj) {
        this.razaoSocial = razaoSocial;
        this.nomeFantasia = nomeFantasia;
        this.cnpj = cnpj;
        
        funcionarios = new ArrayList<Funcionario>();
    }

    public List<Funcionario> getFuncionarios() {
        return funcionarios;
    }

    public void setFuncionarios(List<Funcionario> funcionarios) {
        this.funcionarios = funcionarios;
    }

    public String getRazaoSocial() {
        return razaoSocial;
    }

    public void setRazaoSocial(String razaoSocial) {
        this.razaoSocial = razaoSocial;
    }

    public String getNomeFantasia() {
        return nomeFantasia;
    }

    public void setNomeFantasia(String nomeFantasia) {
        this.nomeFantasia = nomeFantasia;
    }

    public String getCnpj() {
        return cnpj;
    }

    public void setCnpj(String cnpj) {
        this.cnpj = cnpj;
    }
}
