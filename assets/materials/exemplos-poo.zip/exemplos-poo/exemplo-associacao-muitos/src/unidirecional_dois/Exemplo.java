/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package unidirecional_dois;

/**
 *
 * @author 9584013
 */
public class Exemplo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Funcionario f1 = new Funcionario("José da Silva", "012.541.379-33");
        Funcionario f2 = new Funcionario("Maria Pereira", "062.411.632-12");
        Funcionario f3 = new Funcionario("Pedro Ferreira", "178.219.475-25");
        
        Empresa e1 = new Empresa("Empresa 1 LTDA", "Empresa 1", "123.456.789/0001-01");
        Empresa e2 = new Empresa("Empresa 2 LTDA", "Empresa 2", "123.456.789/0001-02");
        
        f1.setEmpresa(e1);
        f2.setEmpresa(e1);
        f3.setEmpresa(e2);
        
        System.out.println(f1.getNome() + " é funcionário na " + f1.getEmpresa().getNomeFantasia());
        System.out.println(f2.getNome() + " é funcionário na " + f2.getEmpresa().getNomeFantasia());
        System.out.println(f3.getNome() + " é funcionário na " + f3.getEmpresa().getNomeFantasia());
    }
    
}
