/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplo;

/**
 *
 * @author 9584013
 */
public class Exemplo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        exemplo4();
    }
    
    public static void exemplo4() {
        Funcionario f = new Gerente();
        f.setSalario(1000);
        System.out.println(f.gratificacao());
    }
    
    public static void exemplo3() {
        Gerente g1 = new Gerente();
        Funcionario f1 = g1;
        Funcionario f2 = new Gerente();
    }
    
    public static void exemplo2() {
        Gerente g = new Gerente();
        g.setSalario(1000);
        
        Funcionario f = new Funcionario();
        f.setSalario(1000);
        
        System.out.println(g.gratificacao()); //Imprimirá 750.0
        System.out.println(f.gratificacao()); //Imprimirá 500.0
    }
    
    public static void exemplo1() {
        Gerente g = new Gerente();
        g.setMatricula("123456");
        g.setSalario(4500);
        g.setSubordinados(10);
        g.setSenha(1234);
        System.out.println(g.gratificacao()); //Imprimirá 2250.0
    }
    
}
