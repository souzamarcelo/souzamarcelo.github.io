/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exemplo_compra;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author marcelo
 */
public class ExemploCompra {

    private static List<Compra> compras = new ArrayList<Compra>();
    
    public static void main(String[] args) {
        Compra compra = new Compra();
        compra.setProduto("Camiseta XPTO - TAM M");
        compra.setPrecoUnitario(140.0);
        compra.setQuantidade(2);
        compra.setEnderecoEntrega("Rua Getúlio Vargas, 200 - Ibirama, SC - 89140-000");
        compra.setStatus("Pedido realizado");
        
        compras.add(compra);
        
        Compra compra2 = new Compra("Tênis ABC 42", 300.0, 1, "Caixa Postal 27 - 89140-970", "Pagamento confirmado");
        
        compras.add(compra2);
        
        for(int i = 0; i < compras.size(); i++) {
            Compra c = compras.get(i);
            System.out.println("Compra: " + c.getProduto() + " a " + c.getPrecoUnitario() + "/unidade, totalizando " + c.valorTotal() + ".");
        }
    } 
}
